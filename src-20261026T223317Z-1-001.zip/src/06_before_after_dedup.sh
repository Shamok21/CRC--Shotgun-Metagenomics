#!/bin/bash
# FastQC and MultiQC before and after deduplication

PROJECT="/Volumes/META/metagenomics_project"

# Create output folders
mkdir -p "$PROJECT/results/fastqc_dedup"
mkdir -p "$PROJECT/results/fastqc_before_dedup"

# FastQC after deduplication
fastqc -t 2 \
  --outdir "$PROJECT/results/fastqc_dedup" \
  "$PROJECT"/data/processed/complexity_dedup/*_dedup_*.fastq.gz

# MultiQC after deduplication
multiqc "$PROJECT/results/fastqc_dedup" \
  --outdir "$PROJECT/results/fastqc_dedup" \
  --filename multiqc_dedup_report.html

# FastQC before deduplication
fastqc -t 2 \
  --outdir "$PROJECT/results/fastqc_before_dedup" \
  "$PROJECT"/data/host_removed/*_nonhost_*.fastq.gz

# MultiQC comparison: before vs after
multiqc \
  "$PROJECT/results/fastqc_before_dedup" \
  "$PROJECT/results/fastqc_dedup" \
  --outdir "$PROJECT/results" \
  --filename multiqc_before_after_dedup.html
