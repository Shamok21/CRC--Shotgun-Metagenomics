#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$HOME/metagenomics_project"

{
  echo "Run date: $(date)"
  echo

  echo "Conda:"
  conda --version
  echo

  echo "SRA Toolkit:"
  prefetch --version
  fasterq-dump --version
  echo

  echo "FastQC:"
  fastqc --version
  echo

  echo "MultiQC:"
  multiqc --version
  echo

  echo "fastp:"
  fastp --version
  echo

  echo "Bowtie2:"
  bowtie2 --version
} > "$PROJECT_DIR/software_versions.txt"
