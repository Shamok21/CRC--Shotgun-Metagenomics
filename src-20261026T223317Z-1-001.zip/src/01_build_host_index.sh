#!/bin/bash

# Human reference genome: GRCh38 primary assembly
# Source: Ensembl release 115

# Go to host directory
cd /Volumes/META/metagenomics_project/host

# Download GRCh38 reference genome
curl -L -o GRCh38.fa.gz \
https://ftp.ensembl.org/pub/release-115/fasta/homo_sapiens/dna/Homo_sapiens.GRCh38.dna.primary_assembly.fa.gz

# Uncompress reference genome
gunzip GRCh38.fa.gz

# Build Bowtie2 index
bowtie2-build --threads 4 GRCh38.fa GRCh38
