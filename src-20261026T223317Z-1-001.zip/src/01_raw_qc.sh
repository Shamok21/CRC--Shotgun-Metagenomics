#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$HOME/metagenomics_project"
RAW_DIR="$PROJECT_DIR/raw_data"
QC_DIR="$PROJECT_DIR/qc_reports/raw"
LOG_DIR="$PROJECT_DIR/logs"

mkdir -p "$QC_DIR" "$LOG_DIR"

fastqc "$RAW_DIR"/*.fastq.gz \
  -o "$QC_DIR" \
  2>&1 | tee "$LOG_DIR/raw_fastqc.log"

multiqc "$QC_DIR" \
  -o "$QC_DIR" \
  --force \
  2>&1 | tee "$LOG_DIR/raw_multiqc.log"
