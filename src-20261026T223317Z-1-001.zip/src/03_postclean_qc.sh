#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$HOME/metagenomics_project"
TRIM_DIR="$PROJECT_DIR/trimmed_data"
QC_DIR="$PROJECT_DIR/qc_reports/clean"
LOG_DIR="$PROJECT_DIR/logs"

mkdir -p "$QC_DIR" "$LOG_DIR"

fastqc "$TRIM_DIR"/*.clean.fastq.gz \
  -o "$QC_DIR" \
  2>&1 | tee "$LOG_DIR/postclean_fastqc.log"

multiqc "$QC_DIR" \
  -o "$QC_DIR" \
  --force \
  2>&1 | tee "$LOG_DIR/postclean_multiqc.log"
