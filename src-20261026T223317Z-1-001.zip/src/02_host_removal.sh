#!/bin/bash

# Host removal using Bowtie2 and Samtools
# Human reference genome: GRCh38
# Keep paired reads where both mates are unmapped to the human genome

# Create output directory
mkdir -p /Volumes/META/metagenomics_project/data/host_removed

# Go to clean FASTQ directory
cd /Volumes/META/metagenomics_project/data/processed

# Process the six samples sequentially
for SAMPLE in SRR29930198 SRR29930199 SRR29930206 SRR29930207 SRR29930208 SRR29930209
do
  echo "===== Processing $SAMPLE ====="

  bowtie2 --very-sensitive -p 4 \
    -x /Volumes/META/metagenomics_project/host/GRCh38 \
    -1 clean_fastq_for_host_removal/${SAMPLE}_1.clean.fastq.gz \
    -2 clean_fastq_for_host_removal/${SAMPLE}_2.clean.fastq.gz \
  | samtools view -b -f 12 -F 256 - \
  | samtools fastq \
      -1 /Volumes/META/metagenomics_project/data/host_removed/${SAMPLE}_nonhost_1.fastq.gz \
      -2 /Volumes/META/metagenomics_project/data/host_removed/${SAMPLE}_nonhost_2.fastq.gz \
      -0 /dev/null -s /dev/null -n -

  echo "===== Finished $SAMPLE ====="
done
