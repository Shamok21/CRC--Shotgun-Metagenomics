#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$HOME/metagenomics_project"
RAW_DIR="$PROJECT_DIR/raw_data"
LOG_DIR="$PROJECT_DIR/logs"

mkdir -p "$RAW_DIR" "$LOG_DIR"
cd "$RAW_DIR"

SAMPLES=(
  SRR29930208
  SRR29930207
  SRR29930206
  SRR29930209
  SRR29930199
  SRR29930198
)

for srr in "${SAMPLES[@]}"
do
  echo "[$(date)] Starting $srr" | tee -a "$LOG_DIR/download.log"

  prefetch "$srr" 2>&1 | tee -a "$LOG_DIR/download.log"

  fasterq-dump "$srr/$srr.sra" \
    --split-files \
    --threads 4 \
    2>&1 | tee -a "$LOG_DIR/download.log"

  gzip "${srr}_1.fastq" "${srr}_2.fastq"

  echo "[$(date)] Finished $srr" | tee -a "$LOG_DIR/download.log"
done
