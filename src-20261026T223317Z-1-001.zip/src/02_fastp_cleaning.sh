#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$HOME/metagenomics_project"
RAW_DIR="$PROJECT_DIR/raw_data"
TRIM_DIR="$PROJECT_DIR/trimmed_data"
QC_DIR="$PROJECT_DIR/qc_reports/clean"
LOG_DIR="$PROJECT_DIR/logs"

mkdir -p "$TRIM_DIR" "$QC_DIR" "$LOG_DIR"

SAMPLES=(
  SRR29930208
  SRR29930207
  SRR29930206
  SRR29930209
  SRR29930199
  SRR29930198
)

for srr in "${SAMPLES[@]}"
do
  echo "[$(date)] Cleaning $srr" | tee -a "$LOG_DIR/fastp.log"

  fastp \
    -i "$RAW_DIR/${srr}_1.fastq.gz" \
    -I "$RAW_DIR/${srr}_2.fastq.gz" \
    -o "$TRIM_DIR/${srr}_1.clean.fastq.gz" \
    -O "$TRIM_DIR/${srr}_2.clean.fastq.gz" \
    --detect_adapter_for_pe \
    --qualified_quality_phred 20 \
    --length_required 50 \
    --thread 4 \
    --html "$QC_DIR/${srr}_fastp.html" \
    --json "$QC_DIR/${srr}_fastp.json" \
    2>&1 | tee "$LOG_DIR/${srr}_fastp.log"
done
